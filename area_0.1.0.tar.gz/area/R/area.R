#'Creates area
#'@export
rect_area <- function(length,width){
  area <- length*width
  return(area)
}


circ_area<-function(radius){
  area<- 3.1416*radius*radius
  return(area)
}


tri_area<-function(base,height){
  area<- 0.5*base*height
  return(area)
}

square_area<-function(side){
  area<- side*side
  return(area)
}

parallel_area<-function(base,height){
  area<- base*height
  return(area)
}

rhombus_area_d<-function(diagonal1,diagonal2){
  area<- 0.5*diagonal1*diagonal2
  return(area)
}

rhombus_area<-function(base,height){
  area<- base*height
  return(area)
}

